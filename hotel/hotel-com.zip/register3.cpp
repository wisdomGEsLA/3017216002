#include "register3.h"
#include "ui_register3.h"
#include <QStandardItem>
#include <QDateTime>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QStandardItemModel>
#include <QSqlQuery>
#include <QDebug>
#include <string.h>
#include <stdlib.h>
#include "register5.h"


Register3::Register3(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Register3)
{
    ui->setupUi(this);
}

Register3::~Register3()
{
    delete ui;
}

extern QString clientid;

void Register3::on_pushButton_4_clicked()
{
    QString ID = clientid;
    QString name = this->ui->lineEdit->text();
    QString gender = this->ui->lineEdit_2->text();
    QString age = this->ui->lineEdit_3->text();
    QString telephone = this->ui->lineEdit_5->text();

    QSqlQuery query;

    QString str = tr("insert into client(ID,name,gender,age,telephone) values('%1','%2','%3',%4,'%5')").arg(ID).arg(name).arg(gender).arg(age).arg(telephone);
    qDebug()<<str;
    query.exec(str);


}

void Register3::on_pushButton_clicked()
{
    this->close();
}

void Register3::on_pushButton_3_clicked()
{
    Register4window = new Register4();
    Register4window->show();
}
