﻿#include "checkout.h"
#include "ui_checkout.h"
#include <QStandardItem>
#include <QDateTime>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QStandardItemModel>
#include <QSqlQuery>
#include <QDebug>
#include <QTableView>

QString CheckOut::room_id;
QString CheckOut::out_time;
QString CheckOut::rent;
QDateTime CheckOut::outtime;

CheckOut::CheckOut(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CheckOut)
{
    ui->setupUi(this);
    show_information();
}

CheckOut::~CheckOut()
{
    delete ui;
}

void CheckOut::on_pushButton_clicked()
{
    emit sendsignals();
    this->hide();
}

void CheckOut::on_pushButton_2_clicked()
{
    room_id = this->ui->lineEdit->text();
    rent = this->ui->lineEdit_2->text();
    out_time = this->ui->lineEdit_3->text();
    outtime = QDateTime::fromString(out_time, "yyyy-MM-dd hh:mm:ss");

    QSqlQuery query;
    QString sql = tr("UPDATE reservation SET rent='%1',checkout_time='%2' WHERE room_id='%3'").arg(rent).arg(out_time).arg(room_id);
    bool ok = query.exec(sql);
    if (ok)
        qDebug()<<"ok";
}

void CheckOut::show_information()
{
    QSqlQueryModel *model = new QSqlQueryModel();
    QString sql = tr("select * from reservation where room_id = '%1'").arg(room_id);
    model->setQuery(sql);
    model->setHeaderData(0,Qt::Horizontal,tr("订单号"));
    model->setHeaderData(1,Qt::Horizontal,tr("证件号"));
    model->setHeaderData(2,Qt::Horizontal,tr("房间号"));
    model->setHeaderData(3,Qt::Horizontal,tr("姓名"));
    model->setHeaderData(4,Qt::Horizontal,tr("电话"));
    model->setHeaderData(5,Qt::Horizontal,tr("入住时间"));
    model->setHeaderData(6,Qt::Horizontal,tr("退房时间"));
    model->setHeaderData(7,Qt::Horizontal,tr("订金"));
    model->setHeaderData(8,Qt::Horizontal,tr("租金"));
    ui->tableView->setModel(model);
}
