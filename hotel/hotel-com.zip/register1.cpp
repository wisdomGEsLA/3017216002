#include "register1.h"
#include "register2.h"
#include "ui_register1.h"
#include <QStandardItem>
#include <QDateTime>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QStandardItemModel>
#include <QSqlQuery>
#include <QDebug>

QString orderid ;
QString clientid ;
QDate checkintime;
QString deposit;
QString roomrates;
QDate checkouttime;

Register1::Register1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Register1)
{
    ui->setupUi(this);
}

Register1::~Register1()
{
    delete ui;
}

void Register1::on_pushButton_2_clicked()
{
    orderid = this->ui->lineEdit->text();
    clientid = this->ui->lineEdit_2->text();
    checkintime = this->ui->dateEdit->date();
    checkouttime = this->ui->dateEdit_2->date();
    deposit = this->ui->lineEdit_6->text();
    roomrates = this->ui->lineEdit_7->text();

    qDebug()<<checkintime<<checkouttime;

    Register2window = new Register2();
    Register2window->show();


}

void Register1::on_pushButton_clicked()
{
    this->close();
}
